<template>
  <div>
    <h1>Babylon Human Body</h1>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>