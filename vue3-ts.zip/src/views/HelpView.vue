<script setup lang="ts"></script>

<template>
  <div class="page">
    <h2>帮助中心</h2>
    <p>这里是帮助中心页，按需替换为真实内容。</p>
  </div>
</template>

<style scoped>
.page {
  padding: 24px;
}
</style>

